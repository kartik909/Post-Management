import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
//import { CookieService } from '.ngx-cookie-service';

import { AppComponent } from './app.component';
import { LoginComponent } from './pages/login/login.component';
import { RegisterComponent } from './pages/register/register.component';
import { NavigationComponent } from './pages/navigation/navigation.component';
import { HomeComponent } from './pages/home/home.component';
import { PostsComponent } from './pages/posts/posts.component';
import { AuthGuard } from './guards/auth.guard';
import { AuthinterceptorService } from './auth/authinterceptor.service';
import { HttpClientModule } from '@angular/common/http';
import { BlogService } from './blogs/blog.service';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    NavigationComponent,
    HomeComponent,
    PostsComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      {path: '', component: HomeComponent},
      {path: 'register', component: RegisterComponent },
      {path: 'login', component: LoginComponent},
      {path: 'posts', component: PostsComponent, canActivate: [AuthGuard]},
    ])    
  ],
  providers: [AuthGuard, BlogService
    // Intercepter implementation
  ],

  bootstrap: [AppComponent]
})
export class AppModule { }
