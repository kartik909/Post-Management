import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BlogService {

  constructor(private _http: HttpClient) { }
 
  getBlogs(){
    this._http.get('http://localhost:3000/blogs').subscribe((resp) =>{
      console.log(resp);      
    });
  }
  
}
